TARGET_SUPPORTS_SHARED_LIBS
---------------------------

Does the target platform support shared libraries.

TARGET_SUPPORTS_SHARED_LIBS is a boolean specifying whether the target
platform supports shared libraries.  Basically all current general
general purpose OS do so, the exception are usually embedded systems
with no or special OSs.
