CTEST_CUSTOM_MEMCHECK_IGNORE
----------------------------

A list of regular expressions to use to exclude tests during the
:command:`ctest_memcheck` command.

.. include:: CTEST_CUSTOM_XXX.txt
