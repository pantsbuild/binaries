CTEST_CUSTOM_TEST_IGNORE
------------------------

A list of regular expressions to use to exclude tests during the
:command:`ctest_test` command.

.. include:: CTEST_CUSTOM_XXX.txt
