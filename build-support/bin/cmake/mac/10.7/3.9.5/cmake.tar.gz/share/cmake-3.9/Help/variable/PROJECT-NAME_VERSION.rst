<PROJECT-NAME>_VERSION
----------------------

Value given to the ``VERSION`` option of the most recent call to the
:command:`project` command with project name ``<PROJECT-NAME>``, if any.

See also the component-wise version variables
:variable:`<PROJECT-NAME>_VERSION_MAJOR`,
:variable:`<PROJECT-NAME>_VERSION_MINOR`,
:variable:`<PROJECT-NAME>_VERSION_PATCH`, and
:variable:`<PROJECT-NAME>_VERSION_TWEAK`.
