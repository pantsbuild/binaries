INCLUDE_REGULAR_EXPRESSION
--------------------------

Include file scanning regular expression.

This property specifies the regular expression used during
dependency scanning to match include files that should be followed.
See the :command:`include_regular_expression` command for a high-level
interface to set this property.
