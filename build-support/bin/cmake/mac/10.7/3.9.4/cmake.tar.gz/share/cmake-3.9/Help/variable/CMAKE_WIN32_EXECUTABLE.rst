CMAKE_WIN32_EXECUTABLE
----------------------

Default value for :prop_tgt:`WIN32_EXECUTABLE` of targets.

This variable is used to initialize the :prop_tgt:`WIN32_EXECUTABLE` property
on all the targets.  See that target property for additional information.
