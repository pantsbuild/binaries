CMAKE_MINIMUM_REQUIRED_VERSION
------------------------------

Version specified to :command:`cmake_minimum_required` command

Variable containing the ``VERSION`` component specified in the
:command:`cmake_minimum_required` command.
