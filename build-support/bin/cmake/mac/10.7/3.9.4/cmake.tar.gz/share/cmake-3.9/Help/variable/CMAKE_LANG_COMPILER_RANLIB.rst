CMAKE_<LANG>_COMPILER_RANLIB
----------------------------

A wrapper around ``ranlib`` adding the appropriate ``--plugin`` option for the
compiler.

See also :variable:`CMAKE_RANLIB`.
