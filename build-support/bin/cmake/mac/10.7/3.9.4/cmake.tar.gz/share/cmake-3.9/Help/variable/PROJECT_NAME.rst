PROJECT_NAME
------------

Name of the project given to the project command.

This is the name given to the most recent :command:`project` command.
