CMAKE_FIND_ROOT_PATH_MODE_LIBRARY
---------------------------------

.. |FIND_XXX| replace:: :command:`find_library`

.. include:: CMAKE_FIND_ROOT_PATH_MODE_XXX.txt
