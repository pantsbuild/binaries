PROJECT_DESCRIPTION
-------------------

Short project description given to the project command.

This is the description given to the most recent :command:`project` command.
