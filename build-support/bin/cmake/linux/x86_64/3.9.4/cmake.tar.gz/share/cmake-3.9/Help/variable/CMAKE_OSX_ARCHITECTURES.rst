CMAKE_OSX_ARCHITECTURES
-----------------------

Target specific architectures for OS X and iOS.

This variable is used to initialize the :prop_tgt:`OSX_ARCHITECTURES`
property on each target as it is creaed.  See that target property
for additional information.

.. include:: CMAKE_OSX_VARIABLE.txt
