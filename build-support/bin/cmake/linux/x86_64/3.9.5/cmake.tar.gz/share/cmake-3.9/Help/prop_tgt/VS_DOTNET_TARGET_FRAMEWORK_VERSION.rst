VS_DOTNET_TARGET_FRAMEWORK_VERSION
----------------------------------

Specify the .NET target framework version.

Used to specify the .NET target framework version for C++/CLI.  For
example, "v4.5".
