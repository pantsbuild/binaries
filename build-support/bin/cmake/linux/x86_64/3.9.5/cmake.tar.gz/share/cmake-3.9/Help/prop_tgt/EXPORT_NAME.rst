EXPORT_NAME
-----------

Exported name for target files.

This sets the name for the IMPORTED target generated when it this
target is is exported.  If not set, the logical target name is used by
default.
