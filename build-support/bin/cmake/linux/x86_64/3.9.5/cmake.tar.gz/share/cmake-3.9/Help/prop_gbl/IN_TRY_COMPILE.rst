IN_TRY_COMPILE
--------------

Read-only property that is true during a try-compile configuration.

True when building a project inside a :command:`try_compile` or
:command:`try_run` command.
