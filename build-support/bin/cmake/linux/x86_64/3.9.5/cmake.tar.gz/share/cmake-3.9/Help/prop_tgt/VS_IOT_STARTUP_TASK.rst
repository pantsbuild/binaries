VS_IOT_STARTUP_TASK
-------------------

Visual Studio Windows 10 IoT Continuous Background Task

Specifies that the target should be compiled as a Continuous Background Task library.
