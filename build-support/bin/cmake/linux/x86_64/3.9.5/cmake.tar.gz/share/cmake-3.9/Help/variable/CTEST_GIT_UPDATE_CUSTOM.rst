CTEST_GIT_UPDATE_CUSTOM
-----------------------

Specify the CTest ``GITUpdateCustom`` setting
in a :manual:`ctest(1)` dashboard client script.
