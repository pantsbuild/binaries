PROCESSORS
----------

How many process slots this test requires

Denotes the number of processors that this test will require.  This is
typically used for MPI tests, and should be used in conjunction with
the ctest_test PARALLEL_LEVEL option.
