VS_DEBUGGER_WORKING_DIRECTORY
-----------------------------

Sets the local debugger working directory for Visual Studio C++ targets.
This is defined in ``<LocalDebuggerWorkingDirectory>`` in the Visual Studio
project file.
